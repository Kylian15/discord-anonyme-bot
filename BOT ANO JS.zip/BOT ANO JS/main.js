const Discord = require("discord.js") // Importe la bibli discord
const intents = new Discord.IntentsBitField(3276799)
const bot = new Discord.Client({intents})
const loadCommands = require("./Loader/loadCommands")
const loadEvents = require("./Loader/loadEvents")
const config = require("./config") // Importe le config.js
const configu = require('./configu.json'); // Importe le configu.json
const currentDate = new Date().toLocaleDateString('fr-FR');
const currentTime = new Date().toLocaleTimeString('fr-FR', {hour: '2-digit', minute:'2-digit'});

bot.commands = new Discord.Collection()


bot.login(config.token) //récup le token du bot
loadCommands(bot)
loadEvents(bot)

