const Discord = require("discord.js")
const loadSlashCommands = require("../Loader/loadSlashCommands")
let config = require('../configu.json')
let language = require('../language.json')
const langue = config.LANGUAGE

module.exports = async bot => {

    await loadSlashCommands(bot)

    console.log(`${bot.user.tag} est bien en ligne !`)
    console.log(`-----------------------------------------------`)
    console.log(langue === 'Fr' ? language.Fr.CREDIT_1 : language.En.CREDIT_1)
    console.log(langue === 'Fr' ? language.Fr.CREDIT_2 : language.En.CREDIT_2)
    console.log(`-----------------------------------------------`)
}