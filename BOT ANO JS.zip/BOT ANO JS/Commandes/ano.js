const Discord = require("discord.js");
const { EmbedBuilder } = require("discord.js");
let config = require('../configu.json');
let language = require('../language.json')
const langue = config.LANGUAGE


module.exports = {
    name: "ano",
    description: langue === 'Fr' ? language.Fr.COMMANDE_DETAIL : language.En.COMMANDE_DETAIL,
    permission: "Aucune",
    dm: false,
    category: "Divers",
    options: [
        {
            type: "string",
            name: langue === 'Fr' ? language.Fr.OPTION_NAME : language.En.OPTION_NAME,
            description: langue === 'Fr' ? language.Fr.OPTION_DETAIL : language.En.OPTION_DETAIL,
            required: true,
            autocomplete: false
        },
    ],

    async run(bot, interaction) {
        const sendingChannelID = config.CHANNELS_ID.CHANNEL_ANO
        const sendingChannel = bot.channels.cache.get(sendingChannelID);
        const description = langue === 'Fr' ? interaction.options.getString("texte"): interaction.options.getString("text");
        const member = interaction.member
        const userTag = member.user.tag;
        const userID = userTag.substring(userTag.lastIndexOf("#") + 1);
        const parsedUserID = parseInt(userID);
        let ano_name;
        
        // Calcul de ano_name selon les spécifications
        if (parsedUserID > 201) {
            ano_name = parsedUserID * 2 - 200;
            if (ano_name > 9999) {
                ano_name -= 10000;
            }
        } else {
            ano_name = parsedUserID * 2;
        }
        // Test pour savoir si l'utilisateur à le rôle PERM Ultime
        if (sendingChannel === interaction.channel) {
            interaction.reply({content:langue === 'Fr' ? language.Fr.COMMANDE_DESCRIPTION: language.En.COMMANDE_DESCRIPTION,ephemeral: true})
            setTimeout(function() {
                interaction.deleteReply();
                const embed = new EmbedBuilder()
                .setTitle(langue === 'Fr' ? language.Fr.EMBED_MESSAGE_TITLE+ano_name: language.En.EMBED_MESSAGE_TITLE+ano_name)
                .setDescription(description)
                .setColor(config.EMBED_COLOR)
                .setFooter({ text: langue === 'Fr' ? language.Fr.EMBED_MESSAGE_FOOTER: language.En.EMBED_MESSAGE_FOOTER, iconURL: config.PIRATE_LOGO})
                interaction.channel.send({ embeds: [ embed ] })
              }, 2000); // 5000 correspond à un délai de 5 secondes (5000 millisecondes)
              

            
        } else {
            const embed = new EmbedBuilder()
                .setTitle(langue === 'Fr' ? language.Fr.EMBED_ERROR_TITLE: language.En.EMBED_ERROR_TITLE)
                .setDescription(langue === 'Fr' ? language.Fr.EMBED_ERROR_DESCRIPTION: language.En.EMBED_ERROR_DESCRIPTION)
                .setThumbnail(config.SERVER_LOGO)
                .setColor(config.EMBED_COLOR)
                .setFooter({ text:language.EMBED_FOOTER_TEXT, iconURL: config.SERVER_LOGO } )
            await interaction.reply({ embeds: [ embed ], ephemeral: true});
        }
        
        const logsChannelID = config.CHANNELS_ID.LOGS;                        // ID du channel de logs
        const logsChannel = bot.channels.cache.get(logsChannelID);
        if (logsChannel) {
            const embed2 = new EmbedBuilder()
            	.setTitle(language.EMBED_LOGS_TITLE)
        		.setThumbnail(config.LOGS_LOGO)
            	.setDescription(langue === 'Fr' ? language.Fr.EMBED_LOGS_DESCRIPTION_1 + `**${member.user.tag}**` + language.Fr.EMBED_LOGS_DESCRIPTION_2 + `**${description}**`:language.En.EMBED_LOGS_DESCRIPTION_1 + `**${member.user.tag}**` + language.En.EMBED_LOGS_DESCRIPTION_2 + `**${description}**`)
            	.setColor(config.EMBED_COLOR)
            	.setFooter({ text: language.EMBED_FOOTER_TEXT, iconURL: config.SERVER_LOGO } )
            logsChannel.send({ embeds: [ embed2 ] })
        }
    }
}
