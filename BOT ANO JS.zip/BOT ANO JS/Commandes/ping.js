const Discord = require("discord.js")
let config = require('../configu.json');

module.exports = {

    name: "ping",
    description: "Affiche la latence",
    permission: "Aucune",
    dm: true,

    async run(bot, message, args) {
        
        await message.reply(`Ping : \`${bot.ws.ping}\``)
    }
}