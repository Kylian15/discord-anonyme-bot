module.exports = {
    token: "YOUR BOT TOKEN HERE !"
}